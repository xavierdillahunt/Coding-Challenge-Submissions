package com.challenge.ingestion_service.service;

public interface RuleEvaluator {

}
