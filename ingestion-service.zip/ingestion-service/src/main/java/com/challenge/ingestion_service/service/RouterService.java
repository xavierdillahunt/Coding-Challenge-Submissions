package com.challenge.ingestion_service.service;

import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class RouterService {
    public String route(String decision, List<Map<String, String>> payload) {
        switch (decision) {
            case "bulk":
                return "Sent to Kafka";
            case "standard":
                return "Written to DB";
            default:
                return "Sent to Email Queue";
        }
    }
}