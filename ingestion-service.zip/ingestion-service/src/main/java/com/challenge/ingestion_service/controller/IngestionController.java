package com.challenge.ingestion_service.controller;

import com.challenge.ingestion_service.service.*;
import com.challenge.ingestion_service.model.UploadResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/upload")
public class IngestionController {

    @Autowired
    private ACETransformer aceTransformer;

    @Autowired
    private DecisionServiceClient decisionServiceClient;

    @Autowired
    private RouterService routerService;

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<UploadResponse> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            String rawCsv = new String(file.getBytes());
            List<Map<String, String>> transformed = aceTransformer.transform(rawCsv);
            String decision = decisionServiceClient.evaluate(transformed);
            String routeResult = routerService.route(decision, transformed);
            return ResponseEntity.ok(new UploadResponse(routeResult));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body(new UploadResponse("error"));
        }
    }
}