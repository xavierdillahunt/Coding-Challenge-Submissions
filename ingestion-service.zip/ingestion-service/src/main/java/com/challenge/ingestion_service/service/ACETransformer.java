package com.challenge.ingestion_service.service;

import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class ACETransformer {
    public List<Map<String, String>> transform(String csv) {
        List<Map<String, String>> result = new ArrayList<>();
        String[] lines = csv.split("\\r?\\n");
        String[] headers = lines[0].split(",");
        for (int i = 1; i < lines.length; i++) {
            String[] row = lines[i].split(",");
            Map<String, String> entry = new HashMap<>();
            for (int j = 0; j < headers.length && j < row.length; j++) {
                entry.put(headers[j], row[j]);
            }
            result.add(entry);
        }
        return result;
    }
}
