package com.challenge.ingestion_service.service;

import java.util.List;
import java.util.Map;

public interface Transformer {
    List<Map<String, String>> transform(String rawInput);
}
