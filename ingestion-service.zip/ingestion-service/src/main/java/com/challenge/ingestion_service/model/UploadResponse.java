package com.challenge.ingestion_service.model;

public class UploadResponse {
    private String result;

    public UploadResponse(String result) {
        this.result = result;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
