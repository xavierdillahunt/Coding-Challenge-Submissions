package com.challenge.ingestion_service.service;

import org.springframework.stereotype.Component;
import java.util.*;

@Component
public class DecisionServiceClient {
    public String evaluate(List<Map<String, String>> data) {
        return data.size() > 10 ? "bulk" : "standard";
    }
}