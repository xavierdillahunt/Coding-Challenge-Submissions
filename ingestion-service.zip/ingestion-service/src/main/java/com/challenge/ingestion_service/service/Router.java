package com.challenge.ingestion_service.service;

import java.util.List;
import java.util.Map;

public interface Router {
    String route(String decision, List<Map<String, String>> payload);
}
