# File Upload & Rule Evaluation API

A **Flask-based API** for uploading CSV files and evaluating each record against data validation rules, returning detailed error reporting and summaries.

---

## Prerequisites

- **Python 3.12** (ensure `py` launcher is available)
- **PowerShell** (for Windows command-line usage)

---

## Setup Instructions

1. **Create and activate a virtual environment:**

   ```powershell
   py -3.12 -m venv venv
   venv\Scripts\activate.bat
   ```

2. **Install dependencies:**

   ```powershell
   pip install Flask==2.3.3 Werkzeug==2.3.7 flask-cors==4.0.0 pandas
   ```

3. **Start the API server:**

   ```powershell
   python app.py
   ```

---

## API Endpoints

### 1. Health Check

- **Endpoint:** `GET /health`
- **Purpose:** Confirm the API is running.

  ```powershell
  curl.exe http://localhost:5000/health
  ```

  **Sample Response:**
  ```json
  {
    "message": "File Upload & Rule Evaluation API is running",
    "status": "healthy"
  }
  ```

---

### 2. Upload CSV File

- **Endpoint:** `POST /upload`
- **Purpose:** Upload a CSV file for validation.
- **Content-Type:** `multipart/form-data`
- **Form Data:**  
  - `file` — the CSV file to upload

  ```powershell
  curl.exe -X POST -F "file=@sample_data.csv" http://localhost:5000/upload
  ```

  **Sample Response:**
  ```json
  {
    "data": {
      "invalid_records": [
        {
          "errors": [
            {
              "field": "email",
              "message": "Invalid email format",
              "type": "invalid_email",
              "value": "invalid-email"
            }
          ],
          "processed_at": "2025-07-09T12:59:54.901951",
          "record": {
            "age": 25,
            "date": "2023-02-20",
            "email": "invalid-email",
            "name": "Jane Smith",
            "phone": "555-123-4567",
            "salary": 60000
          },
          "row_number": 2
        },
        {
          "errors": [
            {
              "field": "age",
              "message": "Age must be between 0 and 150",
              "type": "invalid_age",
              "value": 200
            },
            {
              "field": "phone",
              "message": "Invalid phone number format",
              "type": "invalid_phone",
              "value": "123"
            },
            {
              "field": "date",
              "message": "Invalid date format (expected: YYYY-MM-DD or MM/DD/YYYY)",
              "type": "invalid_date",
              "value": "invalid-date"
            }
          ],
          "processed_at": "2025-07-09T12:59:54.902951",
          "record": {
            "age": 200,
            "date": "invalid-date",
            "email": "bob@test.com",
            "name": "Bob Johnson",
            "phone": "123",
            "salary": 75000
          },
          "row_number": 3
        },
        {
          "errors": [
            {
              "field": "name",
              "message": "name is required and cannot be empty",
              "type": "required_field_missing",
              "value": ""
            }
          ],
          "processed_at": "2025-07-09T12:59:54.902951",
          "record": {
            "age": 35,
            "date": "2023-04-05",
            "email": "missing@email.com",
            "name": "",
            "phone": "5551234567",
            "salary": 55000
          },
          "row_number": 5
        }
      ],
      "summary": {
        "invalid_count": 3,
        "total_processed": 5,
        "valid_count": 2,
        "validation_errors": {
          "invalid_age": 1,
          "invalid_date": 1,
          "invalid_email": 1,
          "invalid_phone": 1,
          "required_field_missing": 1
        }
      },
      "valid_records": [
        {
          "processed_at": "2025-07-09T12:59:54.901951",
          "record": {
            "age": 30,
            "date": "2023-01-15",
            "email": "john@example.com",
            "name": "John Doe",
            "phone": "1234567890",
            "salary": 50000
          },
          "row_number": 1
        },
        {
          "processed_at": "2025-07-09T12:59:54.902951",
          "record": {
            "age": 28,
            "date": "2023-03-10",
            "email": "alice@company.com",
            "name": "Alice Brown",
            "phone": "+1-555-987-6543",
            "salary": 45000
          },
          "row_number": 4
        }
      ]
    },
    "invalid_records": 3,
    "message": "File processed successfully",
    "original_filename": "sample_data.csv",
    "processed_records": 2,
    "status": "success",
    "summary": {
      "invalid_count": 3,
      "total_processed": 5,
      "valid_count": 2,
      "validation_errors": {
        "invalid_age": 1,
        "invalid_date": 1,
        "invalid_email": 1,
        "invalid_phone": 1,
        "required_field_missing": 1
      }
    },
    "total_records": 5
  }
  ```

---

## Response Structure

| Key                  | Description                                                         |
|----------------------|---------------------------------------------------------------------|
| **valid_records**    | List of records passing all validation checks.                      |
| **invalid_records**  | List of records with validation errors; includes error details.     |
| **summary**          | Count of valid/invalid records and error types.                     |
| **message**          | Status message.                                                     |
| **status**           | `"success"` or `"failure"` depending on the process result.         |
| **original_filename**| Name of the uploaded file.                                          |
| **total_records**    | Total number of records processed from the file.                    |


```json
{
  "data": {
    "invalid_records": [
      {
        "errors": [
          {
            "field": "string",
            "message": "string",
            "type": "string",
            "value": "any"
          }
        ],
        "processed_at": "string (ISO 8601 timestamp)",
        "record": {
          "age": "integer",
          "date": "string",
          "email": "string",
          "name": "string",
          "phone": "string",
          "salary": "integer"
        },
        "row_number": "integer"
      }
      // ...
    ],
    "summary": {
      "invalid_count": "integer",
      "total_processed": "integer",
      "valid_count": "integer",
      "validation_errors": {
        "invalid_age": "integer",
        "invalid_date": "integer",
        "invalid_email": "integer",
        "invalid_phone": "integer",
        "required_field_missing": "integer"
      }
    },
    "valid_records": [
      {
        "processed_at": "string (ISO 8601 timestamp)",
        "record": {
          "age": "integer",
          "date": "string",
          "email": "string",
          "name": "string",
          "phone": "string",
          "salary": "integer"
        },
        "row_number": "integer"
      }
      // ...
    ]
  },
  "invalid_records": "integer",
  "message": "string",
  "original_filename": "string",
  "processed_records": "integer",
  "status": "string (success|failure)",
  "summary": {
    "invalid_count": "integer",
    "total_processed": "integer",
    "valid_count": "integer",
    "validation_errors": {
      "invalid_age": "integer",
      "invalid_date": "integer",
      "invalid_email": "integer",
      "invalid_phone": "integer",
      "required_field_missing": "integer"
    }
  },
  "total_records": "integer"
}
```

**Notes:**
- Ensure your CSV follows the required structure and includes all necessary fields for validation.
- All validation and error reporting is performed server-side—no client-side validation is assumed.
- The API can be extended to add new rules or output formats as needed.
- Replace `"string"` and `"integer"` with actual values in real responses.
- Timestamps use ISO 8601 format.
- Both `data.summary` and top-level `summary` share the same structure for convenience.
- Arrays may contain multiple objects; example shows structure for one.

---
