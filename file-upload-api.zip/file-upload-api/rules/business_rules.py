import re
from datetime import datetime
from typing import List, Dict, Any

class BusinessRules:
    def __init__(self):
        self.rules = {
            'email_validation': self._validate_email,
            'age_validation': self._validate_age,
            'phone_validation': self._validate_phone,
            'required_fields': self._validate_required_fields,
            'date_validation': self._validate_dates,
            'numeric_validation': self._validate_numeric_fields
        }
    
    def apply_rules(self, data: List[Dict]) -> Dict[str, Any]:
        """Apply all business rules to the data"""
        valid_records = []
        invalid_records = []
        validation_summary = {
            'total_processed': len(data),
            'valid_count': 0,
            'invalid_count': 0,
            'validation_errors': {}
        }
        
        for idx, record in enumerate(data):
            validation_result = self._validate_record(record, idx)
            
            if validation_result['is_valid']:
                valid_records.append({
                    'record': record,
                    'row_number': idx + 1,
                    'processed_at': datetime.now().isoformat()
                })
            else:
                invalid_records.append({
                    'record': record,
                    'row_number': idx + 1,
                    'errors': validation_result['errors'],
                    'processed_at': datetime.now().isoformat()
                })
                
                # Track error types
                for error in validation_result['errors']:
                    error_type = error['type']
                    if error_type not in validation_summary['validation_errors']:
                        validation_summary['validation_errors'][error_type] = 0
                    validation_summary['validation_errors'][error_type] += 1
        
        validation_summary['valid_count'] = len(valid_records)
        validation_summary['invalid_count'] = len(invalid_records)
        
        return {
            'valid_records': valid_records,
            'invalid_records': invalid_records,
            'summary': validation_summary
        }
    
    def _validate_record(self, record: Dict, row_idx: int) -> Dict[str, Any]:
        """Validate a single record against all rules"""
        errors = []
        
        # Apply each validation rule
        for rule_name, rule_func in self.rules.items():
            try:
                rule_errors = rule_func(record)
                if rule_errors:
                    errors.extend(rule_errors)
            except Exception as e:
                errors.append({
                    'type': 'rule_execution_error',
                    'field': 'unknown',
                    'message': f'Error in {rule_name}: {str(e)}'
                })
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors
        }
    
    def _validate_email(self, record: Dict) -> List[Dict]:
        """Validate email format"""
        errors = []
        email_fields = ['email', 'Email', 'EMAIL', 'email_address']
        
        for field in email_fields:
            if field in record and record[field]:
                email = str(record[field]).strip()
                if email and not self._is_valid_email(email):
                    errors.append({
                        'type': 'invalid_email',
                        'field': field,
                        'value': email,
                        'message': 'Invalid email format'
                    })
        
        return errors
    
    def _validate_age(self, record: Dict) -> List[Dict]:
        """Validate age field"""
        errors = []
        age_fields = ['age', 'Age', 'AGE']
        
        for field in age_fields:
            if field in record and record[field]:
                try:
                    age = int(record[field])
                    if age < 0 or age > 150:
                        errors.append({
                            'type': 'invalid_age',
                            'field': field,
                            'value': age,
                            'message': 'Age must be between 0 and 150'
                        })
                except (ValueError, TypeError):
                    errors.append({
                        'type': 'invalid_age_format',
                        'field': field,
                        'value': record[field],
                        'message': 'Age must be a valid number'
                    })
        
        return errors
    
    def _validate_phone(self, record: Dict) -> List[Dict]:
        """Validate phone number format"""
        errors = []
        phone_fields = ['phone', 'Phone', 'PHONE', 'phone_number', 'mobile']
        
        for field in phone_fields:
            if field in record and record[field]:
                phone = str(record[field]).strip()
                if phone and not self._is_valid_phone(phone):
                    errors.append({
                        'type': 'invalid_phone',
                        'field': field,
                        'value': phone,
                        'message': 'Invalid phone number format'
                    })
        
        return errors
    
    def _validate_required_fields(self, record: Dict) -> List[Dict]:
        """Validate required fields are not empty"""
        errors = []
        required_fields = ['name', 'Name', 'NAME']
        
        for field in required_fields:
            if field in record:
                value = str(record[field]).strip() if record[field] else ''
                if not value:
                    errors.append({
                        'type': 'required_field_missing',
                        'field': field,
                        'value': '',
                        'message': f'{field} is required and cannot be empty'
                    })
        
        return errors
    
    def _validate_dates(self, record: Dict) -> List[Dict]:
        """Validate date fields"""
        errors = []
        date_fields = ['date', 'Date', 'DATE', 'birth_date', 'created_date']
        
        for field in date_fields:
            if field in record and record[field]:
                date_str = str(record[field]).strip()
                if date_str and not self._is_valid_date(date_str):
                    errors.append({
                        'type': 'invalid_date',
                        'field': field,
                        'value': date_str,
                        'message': 'Invalid date format (expected: YYYY-MM-DD or MM/DD/YYYY)'
                    })
        
        return errors
    
    def _validate_numeric_fields(self, record: Dict) -> List[Dict]:
        """Validate numeric fields"""
        errors = []
        numeric_fields = ['salary', 'Salary', 'SALARY', 'amount', 'price']
        
        for field in numeric_fields:
            if field in record and record[field]:
                try:
                    value = float(str(record[field]).replace(',', '').replace('$', ''))
                    if value < 0:
                        errors.append({
                            'type': 'negative_numeric_value',
                            'field': field,
                            'value': record[field],
                            'message': f'{field} cannot be negative'
                        })
                except (ValueError, TypeError):
                    errors.append({
                        'type': 'invalid_numeric_format',
                        'field': field,
                        'value': record[field],
                        'message': f'{field} must be a valid number'
                    })
        
        return errors
    
    def _is_valid_email(self, email: str) -> bool:
        """Check if email format is valid"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    def _is_valid_phone(self, phone: str) -> bool:
        """Check if phone number format is valid"""
        # Remove common formatting characters
        cleaned_phone = re.sub(r'[\s\-\(\)\+]', '', phone)
        # Check if it's 10-15 digits
        return re.match(r'^\d{10,15}$', cleaned_phone) is not None
    
    def _is_valid_date(self, date_str: str) -> bool:
        """Check if date format is valid"""
        date_formats = ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y', '%Y/%m/%d']
        
        for fmt in date_formats:
            try:
                datetime.strptime(date_str, fmt)
                return True
            except ValueError:
                continue
        
        return False
    
    def get_rule_descriptions(self) -> Dict[str, str]:
        """Get descriptions of all business rules"""
        return {
            'email_validation': 'Validates email format using regex pattern',
            'age_validation': 'Ensures age is between 0 and 150',
            'phone_validation': 'Validates phone number format (10-15 digits)',
            'required_fields': 'Checks that required fields (name) are not empty',
            'date_validation': 'Validates date format (YYYY-MM-DD, MM/DD/YYYY, etc.)',
            'numeric_validation': 'Ensures numeric fields are valid numbers and non-negative'
        }
