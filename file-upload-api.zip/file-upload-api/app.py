 
from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import json
import os
from werkzeug.utils import secure_filename
from utils.file_processor import CSVProcessor
from rules.business_rules import BusinessRules

app = Flask(__name__)
CORS(app)

# Configuration
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['UPLOAD_FOLDER'] = 'uploads'
ALLOWED_EXTENSIONS = {'csv'}

# Create upload directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'message': 'File Upload & Rule Evaluation API is running'
    })

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        # Check if file is present in request
        if 'file' not in request.files:
            return jsonify({
                'error': 'No file provided',
                'status': 'error'
            }), 400

        file = request.files['file']
        
        # Check if file is selected
        if file.filename == '':
            return jsonify({
                'error': 'No file selected',
                'status': 'error'
            }), 400

        # Check file extension
        if not allowed_file(file.filename):
            return jsonify({
                'error': 'Only CSV files are allowed',
                'status': 'error'
            }), 400

        # Process the file
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            
            # Initialize processors
            csv_processor = CSVProcessor()
            business_rules = BusinessRules()
            
            # Convert CSV to JSON
            json_data = csv_processor.csv_to_json(file)
            
            # Apply business rules
            processed_data = business_rules.apply_rules(json_data)
            
            # Return structured response
            return jsonify({
                'status': 'success',
                'message': 'File processed successfully',
                'original_filename': filename,
                'total_records': len(json_data),
                'processed_records': len(processed_data['valid_records']),
                'invalid_records': len(processed_data['invalid_records']),
                'data': processed_data,
                'summary': processed_data['summary']
            })

    except Exception as e:
        return jsonify({
            'error': f'Processing failed: {str(e)}',
            'status': 'error'
        }), 500

@app.route('/rules', methods=['GET'])
def get_rules():
    """Endpoint to view current business rules"""
    business_rules = BusinessRules()
    return jsonify({
        'status': 'success',
        'rules': business_rules.get_rule_descriptions()
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
