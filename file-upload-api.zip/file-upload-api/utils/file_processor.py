import pandas as pd
import json
from io import StringIO

class CSVProcessor:
    def __init__(self):
        self.supported_encodings = ['utf-8', 'latin-1', 'cp1252']
    
    def csv_to_json(self, file_stream):
        """Convert CSV file to JSON format"""
        try:
            # Read file content
            content = file_stream.read()
            
            # Try different encodings
            df = None
            for encoding in self.supported_encodings:
                try:
                    # Reset file pointer
                    file_content = content.decode(encoding)
                    df = pd.read_csv(StringIO(file_content))
                    break
                except (UnicodeDecodeError, pd.errors.EmptyDataError):
                    continue
            
            if df is None:
                raise ValueError("Unable to read CSV file with supported encodings")
            
            # Handle missing values
            df = df.fillna('')
            
            # Convert to JSON
            json_data = df.to_dict('records')
            
            return json_data
            
        except Exception as e:
            raise Exception(f"CSV processing error: {str(e)}")
    
    def validate_csv_structure(self, df, required_columns=None):
        """Validate CSV structure"""
        if required_columns:
            missing_columns = set(required_columns) - set(df.columns)
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")
        
        return True
