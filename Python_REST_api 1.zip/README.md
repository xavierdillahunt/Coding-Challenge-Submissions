# csv rule validation API

This is python REST API built with fastapi that allows users to:
- upload a csv file (Has a multiple reference code, code type )
- convert it to json
- apply multiple business rules(Based on'CODE_ACTIVE_STATUS','CODE' )
- return a structured JSON response file as a downloadable file

# Instal dependencies
pip install -r requirements.txt

# Create and activate virtual environment
python -m venv venv
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt 

# Run the API
 bash command: uvicorn main:app --reload

 API will be available at: http://127.0.0.1:8000/docs

 # Steps to Run
 1. open the UI (/docs)
 2. click POST /reference_input.csv/
 3. upload attached reference_input.csv file
 4. click 
 5. You can also see response in the output Directory
