# Pyhton script for File Upload & Rule Evaluation

from fastapi import FastAPI, UploadFile, File, HTTPException 
from fastapi.responses import FileResponse
import pandas as pd
from io import StringIO
import uuid
import os

app = FastAPI()
UPLOAD_DIR = "output"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def rules_validation(df: pd.DataFrame):
    
    required_cols = ['CODE_TYPE', 'CODE']
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing columns: {', '.join(missing_cols)}")
    
    df["status"] = df["CODE_ACTIVE_STATUS"].apply(lambda x: "INACTIVE" if x == "I" else "ACTIVE" )
    df["status"] = df["CODE"].apply(lambda x: "INCORRECT" if x == "M00377SC1" else "CORRECT" )
    return df

@app.post("/reference_input.csv/")
async def reference_input(file: UploadFile = File(...)):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File types must be CSV")
    
    file_content = await file.read()
    try:
        df = pd.read_csv(StringIO(file_content.decode("utf-8")))
        df = rules_validation(df)
        

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    filename = f"{uuid.uuid4().hex}.json"
    json_path = os.path.join(UPLOAD_DIR, filename)

    df.to_json(json_path, orient="records", indent =4)

    # uncomment below to download the json to local
    return FileResponse(path=json_path, media_type="application/json", filename="processed.json")
    
    # return { "data_code": df.to_dict(orient="records")}