from datetime import date
from typing import List, Optional, Tuple, Dict

UNDER_21_ELIGIBLE_DRUGS = {"DRUG111", "DRUG222", "DRUG333"}
GENDER_SPECIFIC_DRUGS = {
    "Female": {"DRUGF1", "DRUGF2"},
    "Other": {"DRUGX1"}
}

def eligibility_rule(patient, claim):
    if patient.eligibility_status.lower() != "active":
        return {"passed": False, "message": "Eligibility status is not active"}
    if not (patient.eligibility_start <= claim.claim_date <= patient.eligibility_end):
        return {"passed": False, "message": "Claim date outside eligibility period"}
    return {"passed": True, "message": "Eligibility valid"}

def age_rule(patient, claim):
    age = (claim.claim_date - patient.dob).days // 365
    if age < 0 or age > 120:
        return {"passed": False, "message": f"Invalid patient age: {age}"}
    return {"passed": True, "message": f"Age valid ({age})"}

def duplicate_therapy_rule(patient, claim):
    if claim.drug_code in patient.current_medications:
        return {"passed": False, "message": "Duplicate therapy detected"}
    return {"passed": True, "message": "No duplicate therapy"}

def consent_rule(patient, claim):
    if not patient.consent_given:
        return {"passed": False, "message": "Patient consent not given"}
    return {"passed": True, "message": "Consent verified"}

def under_21_drug_check(patient, claim) -> Tuple[Optional[Dict], Optional[str]]:
    age = (claim.claim_date - patient.dob).days // 365
    if age >= 21:
        return None, "Rule skipped: patient is 21 or older"

    if claim.drug_code not in UNDER_21_ELIGIBLE_DRUGS:
        return {"passed": False, "message": f"Drug {claim.drug_code} not allowed for patients under 21"}, None
    return {"passed": True, "message": "Drug allowed for under-21"}, None

def gender_drug_check(patient, claim) -> Tuple[Optional[Dict], Optional[str]]:
    if patient.gender.lower() == "male":
        return None, "Rule skipped: gender is male"

    allowed_drugs = GENDER_SPECIFIC_DRUGS.get(patient.gender)
    if allowed_drugs and claim.drug_code not in allowed_drugs:
        return {"passed": False, "message": f"Drug {claim.drug_code} not approved for gender: {patient.gender}"}, None
    return {"passed": True, "message": f"Drug approved for gender: {patient.gender}"}, None
