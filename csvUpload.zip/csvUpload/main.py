from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List
from datetime import date
import pandas as pd
import io
import json
import sqlite3
from sqlite3 import Connection

from rules import (
    eligibility_rule,
    age_rule,
    duplicate_therapy_rule,
    consent_rule,
    under_21_drug_check,
    gender_drug_check,
)

app = FastAPI()

DB_FILE = "patients.db"

def get_db_connection() -> Connection:
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    conn.execute("""
    CREATE TABLE IF NOT EXISTS patient_results (
        patient_id TEXT PRIMARY KEY,
        data TEXT
    )
    """)
    conn.commit()
    conn.close()

init_db()

class Patient(BaseModel):
    patient_id: str
    first_name: str
    last_name: str
    dob: date
    gender: str
    eligibility_status: str
    eligibility_start: date
    eligibility_end: date
    current_medications: List[str]
    consent_given: bool

class Claim(BaseModel):
    claim_date: date
    drug_code: str
    quantity: int

class PatientClaimRequest(BaseModel):
    patient: Patient
    claim: Claim

@app.post("/check-patient-rules/")
async def check_patient_rules(data: PatientClaimRequest):
    patient = data.patient
    claim = data.claim

    applied_rules = {}
    skipped_rules = {}

    # Core rules always enabled
    core_rules = [
        ("eligibility_rule", eligibility_rule),
        ("age_rule", age_rule),
        ("duplicate_therapy_rule", duplicate_therapy_rule),
        ("consent_rule", consent_rule)
    ]

    for rule_name, rule_func in core_rules:
        result = rule_func(patient, claim)
        applied_rules[rule_name] = {
            "applied": True,
            "passed": result["passed"],
            "message": result["message"]
        }

    # Conditional rules run/skipped per logic
    conditional_rules = [
        ("under_21_drug_check", under_21_drug_check),
        ("gender_drug_check", gender_drug_check)
    ]

    for rule_name, rule_func in conditional_rules:
        result, skip_message = rule_func(patient, claim)
        if result:
            applied_rules[rule_name] = {
                "applied": True,
                "passed": result["passed"],
                "message": result["message"]
            }
        else:
            skipped_rules[rule_name] = skip_message

    return {
        "applied_rules": applied_rules,
        "skipped_rules": skipped_rules
    }
from datetime import datetime

def to_iso_date(date_str):
    # Convert MM/DD/YYYY or M/D/YYYY to YYYY-MM-DD
    try:
        return datetime.strptime(date_str, "%m/%d/%Y").date().isoformat()
    except ValueError:
        # If already ISO or different format, try parsing with dateutil or just return as is
        return date_str

@app.post("/upload-patient-csv/")
async def upload_patient_csv(file: UploadFile = File(...)):
    if not file.filename.endswith(".csv"):
        return JSONResponse(content={"error": "Only CSV files allowed"}, status_code=400)

    contents = await file.read()
    try:
        df = pd.read_csv(io.StringIO(contents.decode("utf-8")))
        summary = {
            "total_patients": 0,
            "patients": []
        }

        for _, row in df.iterrows():
            try:
                payload = {
                    "patient": {
                        "patient_id": str(row["patient_id"]),
                        "first_name": row["first_name"],
                        "last_name": row["last_name"],
                        "dob": to_iso_date(row["dob"]),
                        "gender": row["gender"],
                        "eligibility_status": row["eligibility_status"],
                        "eligibility_start": to_iso_date(row["eligibility_start"]),
                        "eligibility_end": to_iso_date(row["eligibility_end"]),
                        "current_medications": eval(row["current_medications"]),
                        "consent_given": row["consent_given"]
                    },
                    "claim": {
                        "claim_date": to_iso_date(row["claim_date"]),
                        "drug_code": row["drug_code"],
                        "quantity": row["quantity"]
                    }
                }

                patient_claim_req = PatientClaimRequest.parse_obj(payload)
                result = await check_patient_rules(patient_claim_req)

                applied_count = len(result["applied_rules"])
                skipped_count = len(result["skipped_rules"])

                full_data = {
                    "patient_claim": payload,
                    "rules_result": result
                }
                conn = get_db_connection()
                conn.execute("""
                    INSERT OR REPLACE INTO patient_results (patient_id, data)
                    VALUES (?, ?)
                """, (row["patient_id"], json.dumps(full_data)))
                conn.commit()
                conn.close()

                summary["patients"].append({
                    "patient_id": row["patient_id"],
                    "applied_rules_count": applied_count,
                    "skipped_rules_count": skipped_count
                })
                summary["total_patients"] += 1

            except Exception as inner_err:
                summary["patients"].append({
                    "patient_id": row.get("patient_id", "unknown"),
                    "error": str(inner_err)
                })
                summary["total_patients"] += 1

        return summary

    except Exception as e:
        return JSONResponse(content={"error": f"Failed to process file: {str(e)}"}, status_code=500)

@app.get("/patients-list/")
def get_patients_list():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT patient_id FROM patient_results")
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            return {"patients": ""}

        # Extract patient_id values and join with commas
        patient_ids = ",".join(str(row[0]) for row in rows)
        return {"patients": patient_ids}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/patient/{patient_id}")
def get_patient(patient_id: str):
    conn = get_db_connection()
    row = conn.execute("SELECT data FROM patient_results WHERE patient_id = ?", (patient_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Patient not found")

    return json.loads(row["data"])
