import json
import csv
import base64
import io
import boto3
from datetime import datetime, timezone

s3_client = boto3.client("s3")
S3_BUCKET = "scdhhs-mes-dev-operations"

def find_csv_start(lines, header_line):
    for idx , line in enumerate(lines):
        if line.strip().startswith(header_line):
            return idx
    return 0
    
def parse_and_filter_rows(csv_text):
    csv_stream = io.StringIO(csv_text)
    reader = csv.DictReader(csv_stream)

    valid_entries = []
    current_date = datetime.now(timezone.utc).date()

    for record in reader:
        try:
            req_type = record.get('RequestType', '').strip()
            if req_type not in ('Create', 'Update'):
                continue

            name = record.get("FullName", "").strip().title()
            loc = record.get("Location", "").strip()
            status_code = record.get("StatusCode", "").strip().upper()
            evt_date_str = record.get("EventDate", "").strip()
            evt_date = datetime.strptime(evt_date_str, "%Y-%m-%d").date()

            if evt_date > current_date:
                continue

            if not all([name, loc, status_code, req_type, evt_date_str]):
                continue

            days_since = (current_date - evt_date).days

            valid_entries.append({
                'fullName': name,
                'location': loc,
                'status': status_code,
                'requestType': req_type,
                'eventDate': evt_date_str,
                'daysSinceEvent': days_since,
                'eventTimestamp': evt_date.isoformat()
                })
            
        except Exception:
            continue

    return sorted(valid_entries, key= lambda x: x['eventTimestamp'])
    
def lambda_handler(event, context):
    try:
        payload = event.get('body')
        if event.get('isBase64Encoded', False):
            decoded_bytes = base64.b64decode(payload)
            text_payload = decoded_bytes.decode('utf-8')
        else:
            text_payload = payload
        
        all_lines = text_payload.splitlines()
        csv_header = 'FullName,Location,StatusCode,RequestType,EventDate'
        start_line_index = find_csv_start(all_lines, csv_header)
        csv_content = '\n'.join(all_lines[start_line_index:])

        filtered_results = parse_and_filter_rows(csv_content)

        s3_key = f"processed_file.json"
        s3_client.put_object(
            Bucket = S3_BUCKET,
            Key = s3_key,
            Body = json.dumps(filtered_results, indent =2),
            ContentType = 'application/json'
        )

        return{
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"message": "Successfully processed",
                                "data": filtered_results})
        }
    except Exception as e:
        return{
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
