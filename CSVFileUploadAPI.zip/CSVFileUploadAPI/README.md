This Project is File upload API in python, which takes csv file as input from user and convert to json fornamt in output directory.

To use this repo we need -
    1. Python 3.9 or higher
    2. Flask, Pandas - To install use "pip install flask pandas" command.
 
How to Test/Run:
    1. Open command prompt and navigate to CSVFileUploadAPI folder path.
    2. Run "flask run" command
    3. App is running on "http://127.0.0.1:5000" url
    4. Choose provider_data.csv file from CSVFileUploadAPI directory and Upload.
    5. File uploaded message is displayed and json files gets generated under CSVFileUploadAPI/output directory.