def apply_business_rules(provider_data):
    """
    IF Provider FIPS is not valid 8 digit then flag that record.
    """
    for record in provider_data:
        FIPS_NUM = record.get('P_PROV_FIPS', '')
        record['rules_triggered'] = len(str(FIPS_NUM)) != 8
    return provider_data
