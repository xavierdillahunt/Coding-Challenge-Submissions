import io
import os
from flask import Flask, json, request, render_template
import pandas as pd
import business_rules


def create_app():
    app = Flask(__name__)

    @app.route('/')
    def index():
        return render_template('upload.html')

    @app.route('/upload', methods=['POST'])
    def upload():
        if request.method == 'POST':
            if 'file' not in request.files or request.files['file'].filename == '':
                return render_template('upload.html', message='No file selected.')

            file = request.files['file']

            try:
                data_stream = io.StringIO(file.stream.read().decode("UTF8"))
                df = pd.read_csv(data_stream)
                json_data = df.to_dict(orient='records')
                applied_rules = business_rules.apply_business_rules(json_data)

                filename = os.path.splitext(file.filename)[0]
                
                with open(os.path.join('output', filename + '.json'), 'w', encoding='utf-8') as f:
                    json.dump(applied_rules, f, indent=4)

                return render_template('upload.html', message='File uploaded and processed successfully in output folder.')

            except Exception as e:
                return render_template('upload.html', message=f'Error: {str(e)}')

    return app
