package com.codechallange.decision.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.codechallange.common.model.DecisionRequest;
import com.codechallange.common.model.DecisionResponse;

@Service
public class ExternalDecisionServiceClient {

    private final RestTemplate restTemplate;

    @Value("${external.decision.service.url}")
    private String decisionServiceUrl;

    public ExternalDecisionServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public DecisionResponse evaluateDecision(DecisionRequest request) {
        return restTemplate.postForObject(decisionServiceUrl, request, DecisionResponse.class);
    }
}