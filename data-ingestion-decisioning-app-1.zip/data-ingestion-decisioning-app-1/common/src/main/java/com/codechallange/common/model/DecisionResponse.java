package com.codechallange.common.model;

public class DecisionResponse {
    private boolean approved;
    private String message;

    public DecisionResponse() {}

    public DecisionResponse(boolean approved, String message) {
        this.approved = approved;
        this.message = message;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}