package com.codechallange.common.model;

public class DecisionRequest {
    // Add fields as needed
    private String data;

    public DecisionRequest() {}

    public DecisionRequest(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}