package com.codechallange.ingestion.service;

import org.springframework.stereotype.Service;

@Service
public class AwsLambdaService {
    public String[] invokeLambda(String[] payload) {
        // Simulate AWS Lambda invocation
        System.out.println("Invoking AWS Lambda with payload: " + payload);
        // Add actual AWS Lambda SDK code here if needed
        return payload; // Return the payload for demonstration purposes
    }
}