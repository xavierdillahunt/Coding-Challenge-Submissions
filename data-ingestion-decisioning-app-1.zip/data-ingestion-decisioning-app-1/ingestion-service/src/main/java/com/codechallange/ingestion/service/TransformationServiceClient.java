package com.codechallange.ingestion.service;

import org.springframework.stereotype.Service;

@Service
public class TransformationServiceClient {
    public String[] transformData(String[] csvData) {
        // Simulate calling the transformation microservice (e.g., IBM ACE)
        // In real implementation, this could be a REST call
        return csvData;
    }
}