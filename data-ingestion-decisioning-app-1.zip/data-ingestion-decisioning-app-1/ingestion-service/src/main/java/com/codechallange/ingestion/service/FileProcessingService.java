package com.codechallange.ingestion.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;
import com.codechallange.ingestion.service.AwsLambdaService;
import com.codechallange.common.exception.CustomException;
import com.codechallange.ingestion.service.TransformationServiceClient;
@Service
public class FileProcessingService {

    @Autowired
    private AwsLambdaService awsLambdaService; // Service to invoke AWS Lambda functions

    @Autowired
    private TransformationServiceClient transformationServiceClient; // Client to call transformation service

    public void processFile(MultipartFile file) throws IOException {
        List<String[]> csvData = parseCsv(file);
        for (String[] record : csvData) {
            // Invoke AWS Lambda for processing
            String[] processedData = awsLambdaService.invokeLambda(record);
            // Call transformation service
            String[] transformedData = transformationServiceClient.transformData(processedData);
            // Further processing or routing can be done here
        }
    }

    private List<String[]> parseCsv(MultipartFile file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            return reader.lines()
                    .map(line -> line.split(","))
                    .collect(Collectors.toList());
        }
    }
}