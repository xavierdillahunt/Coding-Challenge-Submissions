package com.codechallange.routing.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class EmailQueueRoutingService {

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public EmailQueueRoutingService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void routeToEmailQueue(String emailMessage) {
        // Logic to route the email message to the email queue
        kafkaTemplate.send("emailQueue", emailMessage);
    }
}