package com.codechallange.routing.service;

import com.codechallange.common.model.DataRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class KafkaRoutingService {
    private final KafkaTemplate<String, String> kafkaTemplate;

    public KafkaRoutingService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void routeToKafka(DataRecord record) {
        CompletableFuture<SendResult<String, String>> future =
            kafkaTemplate.send("topic-name", record.getId(), record.getValue());

        future.whenComplete((result, ex) -> {
            if (ex == null) {
                RecordMetadata metadata = result.getRecordMetadata();
                System.out.println("Sent to Kafka: " + metadata.topic() + " partition: " + metadata.partition());
            } else {
                System.err.println("Failed to send to Kafka: " + ex.getMessage());
            }
        });
    }
}