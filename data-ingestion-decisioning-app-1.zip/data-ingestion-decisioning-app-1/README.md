# Data Ingestion and Decisioning Application

This project is a scalable data ingestion and rules-based decisioning engine architecture built using Java microservices with Spring Boot. The application is designed to handle high-volume file uploads, process CSV files, and route transformed results to multiple destinations.

## Project Structure

```
data-ingestion-decisioning-app
├── ingestion-service          # Service for handling file uploads and processing
├── transformation-service     # Service for transforming data using IBM ACE
├── decision-service           # Service for delegating business rules to an external decision service
├── routing-service            # Service for routing results to various destinations
├── common                     # Common utilities and models shared across services
├── docker                     # Docker configurations for each service
└── README.md                  # Project documentation
```

## Technologies Used

- Java 17
- Spring Boot
- Maven
- AWS Cloud Services
- IBM ACE (simulated)
- Kafka
- Docker

## Setup Instructions

1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd data-ingestion-decisioning-app
   ```

2. **Build the Project**
   Use Maven to build the entire project:
   ```bash
   mvn clean install
   ```

3. **Run Individual Services**
   Each service can be run independently. Navigate to the service directory and run:
   ```bash
   cd ingestion-service
   mvn spring-boot:run
   ```

   Repeat for `transformation-service`, `decision-service`, and `routing-service`.

4. **Docker Setup**
   To build Docker images for each service, navigate to the `docker` directory and run:
   ```bash
   docker build -f ingestion.Dockerfile -t ingestion-service .
   docker build -f transformation.Dockerfile -t transformation-service .
   docker build -f decision.Dockerfile -t decision-service .
   docker build -f routing.Dockerfile -t routing-service .
   ```

## Usage Guidelines

- **File Uploads**: The ingestion service accepts high-volume CSV file uploads via its REST API.
- **Data Processing**: Uploaded files are processed, and transformations are applied using the transformation service.
- **Business Rules**: The decision service delegates business rules to an external decision service.
- **Routing**: The routing service routes the transformed results to various destinations, including databases, Kafka topics, and email queues.

## Exception Handling

The application includes a global exception handler to manage errors and provide standardized responses.

## Contributing

Contributions are welcome! Please submit a pull request or open an issue for any enhancements or bug fixes.

## License
