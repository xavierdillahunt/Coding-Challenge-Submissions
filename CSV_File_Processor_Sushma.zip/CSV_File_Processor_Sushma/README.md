#CSV File order Processor
A modular system for processing order csv files with config business rules

## Features

- Processes CSV files with order data
- Applies configurable business rules
- Identifies priority orders
- Generates JSON output files
- Comprehensive error handling

## Installation

1. Ensure Phyton 3.10+ is installed
2. Install dependencies

## Quick Start

```bash

# Create Virtual environment
python -m venv venv
source venv/bin/activate
# 1. Install deps (optionally in a virtual env)
pip install -r requirements.txt

# 2. Run the app
python main.py

# 3. Run all tests from command line:
python -m unittest discover -s tests

```