import json

from rule_engines.base import RuleEngine


class StandardRulesEngine(RuleEngine):
    def __init__(self, config_file):
        self.name = "StandardRulesEngine"
        # configurable rules from JSON
        with open(config_file) as f:
            self.config = json.load(f)

    def apply_rules(self, orders):
        threshold = self.config.get('priority_threshold', 1000)
        for order in orders:
            order.priority = order.amount > threshold
        return orders

    def get_route(self):
        return 'priority' if self.config.get('force_priority', False) else 'standard'
