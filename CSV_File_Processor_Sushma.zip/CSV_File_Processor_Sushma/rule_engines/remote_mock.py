from rule_engines.base import RuleEngine


class RemoteRulesEngine(RuleEngine):
    def __init__(self):
        self.rules = {
            'threshold': 500,
            'special_customers': ['VIP001', 'VIP002']
        }

    def apply_rules(self, orders):
        for order in orders:
            order.priority = (
                    order.amount > self.rules['threshold'] or
                    order.customer_id in self.rules['special_customers']
            )
        return orders

    def get_route(self):
        return 'priority'
