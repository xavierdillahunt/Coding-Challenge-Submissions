from abc import ABC, abstractmethod


class RuleEngine(ABC):
    @abstractmethod
    def apply_rules(self, orders):
        pass

    @abstractmethod
    def get_route(self):
        pass
