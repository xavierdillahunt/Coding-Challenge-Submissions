from file_processor import FileProcessor
from persistence.file_storage import FileStorage
from rule_engines.remote_mock import RemoteRulesEngine
from rule_engines.standard_rules import StandardRulesEngine


def main():
    storage = FileStorage()
    engines = {
        'standard': StandardRulesEngine('config.json'),
        'remote': RemoteRulesEngine()
    }

    csv_file = './orders.csv'
    print("processing with standard rules:")
    result = FileProcessor(engines['standard'], storage).process(csv_file)
    print(result)


if __name__ == "__main__":
    main()
