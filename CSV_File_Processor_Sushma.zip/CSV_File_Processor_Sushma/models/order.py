class Order:
    def __init__(self, order_id, customer_id, amount):
        self.order_id = order_id
        self.customer_id = customer_id
        self.amount = float(amount)
        self.priority = False

    def to_dict(self):
        return {
            'order_id': self.order_id,
            'customer_id': self.customer_id,
            'amount': self.amount,
            'priority': self.priority
        }
