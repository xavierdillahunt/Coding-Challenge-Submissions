import json
import os
from datetime import datetime


class FileStorage:
    def __init__(self, storage_dir='data'):
        self.storage_dir = storage_dir
        os.makedirs(storage_dir, exist_ok=True)

    def save(self, data):
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{self.storage_dir}/result_{timestamp}.json"

        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
