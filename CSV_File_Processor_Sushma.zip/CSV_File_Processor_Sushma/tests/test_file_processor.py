import json
import os
import tempfile
import unittest

from file_processor import FileProcessor
from persistence.file_storage import FileStorage
from rule_engines.standard_rules import StandardRulesEngine


class TestFileProcessor(unittest.TestCase):
    def setUp(self):
        self.temp_dir= tempfile.mkdtemp()
        self.storage = FileStorage(storage_dir=self.temp_dir)
        self.config_file = os.path.join(self.temp_dir, "config.json")
        with open(self.config_file, 'w') as f:
            json.dump({"priority_threshold":1000,"force_priority":False},f)
        self.engine = StandardRulesEngine(self.config_file)
        self.processor = FileProcessor(self.engine,self.storage)

        #Create test CSV
        self.good_csv = os.path.join(self.temp_dir,"testOrder.csv")
        with open(self.good_csv,'w') as f:
            f.write("order_id,customer_id,amount\n")
            f.write("100,CUST001,100.00\n")
            f.write("200,VIP001,1600.00\n")

    def test_process_valid_csv(self):
        result = self.processor.process(self.good_csv)
        self.assertEqual(len(result['orders']), 2)

        #Verify persistence
        saved_files = os.listdir(self.temp_dir)
        self.assertTrue(any(f.startswith("result_") for f in saved_files))

if __name__ == '__main__':
    unittest.main()
