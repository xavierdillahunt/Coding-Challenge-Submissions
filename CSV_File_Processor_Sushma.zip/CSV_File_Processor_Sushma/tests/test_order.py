import unittest

from models.order import Order


class TestOrder(unittest.TestCase):
    def test_order_creation(self):
        order = Order("123","CUST001",200.00)
        self.assertEqual(order.order_id,"123")
        self.assertEqual(order.customer_id, "CUST001")
        self.assertEqual(order.amount, 200.00)
        self.assertFalse(order.priority)

    def test_to_dict(self):
        order = Order("1112", "VIP001", 1200.00)
        order.priority =True
        expected = {
            'order_id':'1112',
            'customer_id':'VIP001',
            'amount':1200.00,
            'priority':True
        }
        self.assertDictEqual(order.to_dict(),expected)

if __name__ == '__main__':
    unittest.main()

