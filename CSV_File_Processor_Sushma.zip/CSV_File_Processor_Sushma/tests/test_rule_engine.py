import json
import os
import tempfile
import unittest

from models.order import Order
from rule_engines.remote_mock import RemoteRulesEngine
from rule_engines.standard_rules import StandardRulesEngine


class TestRuleEngines(unittest.TestCase):
    def setUp(self):
        self.orders = [
            Order("11","CUST001",200.00),
            Order("12", "CUST001", 300.00),
            Order("12", "VIP001", 1200.00)
        ]

    def test_standard_rule_engine_default(self):
        self.temp_dir = tempfile.mkdtemp()
        self.config_file = os.path.join(self.temp_dir, "configTest.json")
        with open(self.config_file, 'w') as f:
            json.dump({"priority_threshold": 1000, "force_priority": False}, f)
        engine = StandardRulesEngine(self.config_file)
        processed = engine.apply_rules(self.orders)
        self.assertFalse(processed[0].priority)
        self.assertTrue(processed[2].priority)

    def test_remote_rule_engine(self):
        engine = RemoteRulesEngine()
        processed = engine.apply_rules(self.orders)
        self.assertFalse(processed[0].priority)
        self.assertFalse(processed[1].priority)
        self.assertTrue(processed[2].priority)
        self.assertEqual(engine.get_route(),"priority")
if __name__ == '__main__':
    unittest.main()
