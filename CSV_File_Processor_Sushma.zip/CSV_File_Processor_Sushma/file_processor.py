import csv

from models.order import Order


class FileProcessor:
    def __init__(self, rule_engine, storage):
        self.rule_engine = rule_engine
        self.storage = storage

    def process(self, file_path):
        # Read and Validate CSV
        csv_content = self._read_csv_file(file_path)
        orders = self._parse_csv(csv_content)
        # Apply business rules
        processed_orders = self.rule_engine.apply_rules(orders)
        route = self.rule_engine.get_route()
        # Store results
        self.storage.save({
            'orders': [po.to_dict() for po in processed_orders],
            'route': route,
            'rules_applied': self.rule_engine.__class__.__name__
        })

        return {
            'orders': [po.to_dict() for po in processed_orders],
            'route': route,
            'rules_applied': self.rule_engine.__class__.__name__
        }

    def _read_csv_file(self, file_path):
        """Read CSV file"""
        try:
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                content = f.read()
            if not content.strip():
                raise ValueError("File is empty")
            return content
        except UnicodeDecodeError:
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    return f.read()
            except Exception as e:
                raise ValueError(f"Could not read file : {str(e)}")

    def _parse_csv(self, csv_content):
        """Parse CSV content into order objects"""
        orders = []
        try:
            lines = [line.strip() for line in csv_content.splitlines() if line.strip()]
            # parse CSV
            reader = csv.DictReader(lines)

            # Validate headers
            required_headers = {'order_id', 'customer_id', 'amount'}
            if not required_headers.issubset(reader.fieldnames):
                missing = required_headers - set(reader.fieldnames)
                raise ValueError(f"Missing required columns: {','.join(missing)}")

            # Process rows
            for i, row in enumerate(reader, start=2):
                try:
                    orders.append(Order(
                        order_id=row['order_id'].strip(),
                        customer_id=row['customer_id'].strip(),
                        amount=self._validate_amount(row['amount'])
                    ))
                except KeyError as e:
                    raise ValueError(f"Missing required field in row: {e}")
                except ValueError as e:
                    raise ValueError(f"Invalid data in row:{e}")

        except csv.Error as e:
            raise ValueError(f"CSV parsing error : {e}")

        if not orders:
            raise ValueError("No valid orders found in CSV")

        return orders

    def _validate_amount(self, amount_str):
        """ Validate and convert amount string to float"""
        try:
            amount = float(amount_str.strip())
            if amount < 0:
                raise ValueError("Amount cannot be negative")
            return amount
        except ValueError:
            raise ValueError(f"Invalid amount value: '{amount_str}'")
