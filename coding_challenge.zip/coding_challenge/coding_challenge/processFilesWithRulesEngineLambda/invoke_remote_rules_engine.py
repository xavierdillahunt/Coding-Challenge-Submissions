import boto3
import json

lambda_client = boto3.client('lambda')


def apply_rules(csv_content_list, rules):
    # invoke remote rules engine - lambda function
    response = lambda_client.invoke(
        FunctionName='RemoteRulesEngine',
        Payload=json.dumps({"csv_content": csv_content_list, "rules": rules})
    )
    return json.loads(response['Payload'].read())