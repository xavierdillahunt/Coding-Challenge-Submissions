import base64
import csv
import json
import os
import uuid
from io import StringIO

import boto3

from invoke_remote_rules_engine import apply_rules


def log_result_to_file(results):
    file_path = "/tmp/upload_log.json"
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            existing_logs = json.load(f)
    else:
        existing_logs = []
    print(existing_logs)
    existing_logs.append(results)
    with open(file_path, 'w') as f:
        json.dump(existing_logs, f, indent=2)
    return file_path


# hard-coded rules--> can be moved to s3
def load_rules():
    rules_json = {"gender": "Female",
                  "maintenanceType": "Add"
                  }
    return json.loads(json.dumps(rules_json))


def extract_csv_content(body_bytes, content_type):
    boundary = content_type.split("boundary=")[-1]
    delimiter = f"--{boundary}".encode()
    # split into parts using boundary
    parts = body_bytes.split(delimiter)
    for part in parts:
        if b"filename=" in part:
            header_end = part.find(b"\r\n\r\n")
            if header_end != -1:
                csv_bytes = part[header_end+4:]
                csv_bytes = csv_bytes.rstrip(b"\r\n--")
                return csv_bytes.decode("utf-8")
    return None


def lambda_handler(event, context):
    content_type = event["headers"].get('Content-Type') or event['headers'].get('content-type')
    # decode base64
    if event.get("isBase64Encoded"):
        body_bytes = base64.b64decode(event["body"])
    else:
        body_bytes = event["body"].encode('utf-8')

    csv_text = extract_csv_content(body_bytes, content_type)
    # convert csv to text
    csv_io = StringIO(csv_text)
    reader = list(csv.DictReader(csv_io))

    rules = load_rules()
    # call remote rules engine
    rule_engine_response = apply_rules(reader, rules)
    log_id = str(uuid.uuid4())
    log_to_file = {
        'id': log_id,
        'rule_engine_response': rule_engine_response,
    }
    file_path = log_result_to_file(log_to_file)
    print(file_path)
    return {"statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(rule_engine_response)}

