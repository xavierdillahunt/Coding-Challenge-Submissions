# rules metadata is hard-coded -> can be parameterized
def rule_details():
    return {"rulesType": "StandardRulesEngine",
            "route": "providerEnrollment"}


def apply_rules(row, rules):
    if "gender" in rules and row["gender"].strip().upper() != rules["gender"].upper():
        return False
    if "maintenance" in rules and row["maintenanceType"].strip().lower() != rules["maintenanceType"].lower():
        return False
    else:
        return row


def lambda_handler(event, context):
    # Fetch data and rules from event
    rows = event["csv_content"]
    rules = event["rules"]
    rules_detail = rule_details()
    # apply business rules
    filtered_rows = [row for row in rows if apply_rules(row, rules)]
    return {
        "providers": filtered_rows,
        "rulesApplied": rules_detail["rulesType"],
        "route": rules_detail["route"]
    }

