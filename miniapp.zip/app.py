from flask import Flask, request, jsonify
import csv
import io

app = Flask(__name__)

def fix_zip(record):
    """
    Simulates inserting a dash in 9 digit zip codes.
    """
    if len(record['M_MEMBER_ZIP_CODE']) > 5:
        record['M_MEMBER_ZIP_CODE'] = record['M_MEMBER_ZIP_CODE'][0:5] + '-' + record['M_MEMBER_ZIP_CODE'][5:]

    return record


def simulate_ace_transform(csv_data):
    """
    Simulate the ACE transformation process.
    """
    # Parse CSV data
    csv_reader = csv.DictReader(io.StringIO(csv_data.decode('utf-8')))
    
    print("")
    print("Simulating transforming data with ACE")
    inbound_data = list(csv_reader)
    
    transformed_data = [fix_zip(record) for record in inbound_data]
    
    return transformed_data


def get_rule_set():
    """
    Simulates a set of rules tat return TRUE for an error that needs to be reported
    """
    rule_set = {
          "DATE OF DEATH BEFORE DATE OF BIRTH": lambda member: member['M_MEMBER_DOD'] < member['M_MEMBER_DOB'],
          "MEMBER DEAD"                       : lambda member: member['M_MEMBER_DOD'] < '9999-12-31',
          "NO ZIP"                            : lambda member: member['M_MEMBER_ZIP_CODE'] == ""
    }
    return rule_set


def execute_rule_set(rule_set, record):
    """
    Executes the rule set against a record
    """
    rule_result = []
    for rule_name, rule_func in rule_set.items():
        if rule_func(record):
            print(" - Rule failed: " + record['M_MEMBER_ID'] + '-' + rule_name)
            rule_result.append(rule_name)

    
    # rule_result = [rule_name for rule_name, rule_func in rule_set.items() if rule_func(record)]
    # print("Rule result: " + rule_result)
    return rule_result


def simulate_odm_evaluation(rule_set, record):
    """
    Simulates sending data to ODM rule evaluator.
    In a real implementation, this would call the actual ODM service.
    """
    # print("Simulating ODM evaluation")
    # print("Transformed data: " + str(record))
    
    failed_rules = execute_rule_set(rule_set, record)
    return failed_rules


@app.route('/ingest', methods=['POST'])
def ingest_csv():
    # Check if file is present in request
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400
    
    file = request.files['file']
    
    # Check if file has a name and is CSV
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400
    
    if not file.filename.endswith('.csv'):
        return jsonify({"error": "Only CSV files are supported"}), 400
    
    try:
        # Get rule set
        rule_set = get_rule_set()
        
        # Read the CSV file
        csv_data = file.read()
        
        # Process through ACE transform
        transformed_data = simulate_ace_transform(csv_data)
        for row in transformed_data:
            print(row['M_MEMBER_ZIP_CODE'])
        
        failed_rules = []
        
        # Send to ODM for rule evaluation
        print('')
        print("Simulating ODM evaluation")

        for transformed_record in transformed_data:
            print("Processing member " + transformed_record['M_MEMBER_ID'])
            odm_result = simulate_odm_evaluation(rule_set, transformed_record)
            if odm_result != []:
                failed_rules.append(transformed_record['M_MEMBER_ID'] + " - " + ','.join(odm_result))
        
        print('')
        print('Failed rules')
        for failed_rule in failed_rules:
            print(failed_rule)
            print('')
        
        # Return the routing outcome
        return jsonify({
            "status": "success",
            "message": "File processed successfully",
            "total_records": len(transformed_data),
            "total_errors": len(failed_rules),
            "failed_rules_by_member": r'|'.join(failed_rules)
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)