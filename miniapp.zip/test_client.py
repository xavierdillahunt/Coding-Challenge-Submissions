import requests
import csv
import os

# Test Ingestion Simulation
def test_ingestion(file_path="sample_data.csv"):
    url = "http://localhost:5000/ingest"
    
    if not os.path.exists(file_path):
        print(f"Error: File {file_path} not found.")
        return
    
    with open(file_path, 'rb') as file:
        files = {'file': file}
        print(f"Sending {file_path} to {url}...")
        
        try:
            response = requests.post(url, files=files)
            print(f"Status Code: {response.status_code}")
            print("Response:")
            print(response.json())
        except Exception as e:
            print(f"Error: {str(e)}")

if __name__ == "__main__":
   
    # Test the ingestion endpoint
    test_ingestion()
    
    print("Test complete.")