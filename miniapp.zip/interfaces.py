from abc import ABC, abstractmethod
from typing import Dict, List, Any, Callable


class ACETransformerInterface(ABC):
    """
    Interface for ACE (Advanced Content Extraction) transformations.
    Implementations of this interface will handle data transformation from various formats.
    """
    
    @abstractmethod
    def transform(self, raw_data: bytes) -> List[Dict[str, Any]]:
        """
        Transform raw data into a standardized format.
        
        Args:
            raw_data: Raw data bytes to transform
            
        Returns:
            List of dictionaries representing transformed records
        """
        pass


class ODMRuleEngineInterface(ABC):
    """
    Interface for ODM (Operational Decision Management) rule evaluation.
    Implementations will handle business rule evaluation against data.
    """
    
    @abstractmethod
    def get_rule_set(self) -> Dict[str, Callable]:
        """
        Get the set of rules to be evaluated.
        
        Returns:
            Dictionary mapping rule names to rule evaluation functions
        """
        pass
    
    @abstractmethod
    def evaluate_rules(self, record: Dict[str, Any]) -> List[str]:
        """
        Evaluate rules against a single record.
        
        Args:
            record: Dictionary containing record data
            
        Returns:
            List of failed rule names
        """
        pass


class AIProcessorInterface(ABC):
    """
    Interface for AI processing capabilities.
    Implementations will provide AI-based analysis and processing of data.
    """
    
    @abstractmethod
    def analyze_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze a single record using AI capabilities.
        
        Args:
            record: Dictionary containing record data
            
        Returns:
            Dictionary with analysis results
        """
        pass
    
    @abstractmethod
    def batch_analyze(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Analyze a batch of records using AI capabilities.
        
        Args:
            records: List of dictionaries containing record data
            
        Returns:
            List of dictionaries with analysis results
        """
        pass
    
    @abstractmethod
    def suggest_corrections(self, record: Dict[str, Any], issues: List[str]) -> Dict[str, Any]:
        """
        Suggest corrections for issues found in a record.
        
        Args:
            record: Dictionary containing record data
            issues: List of issue identifiers
            
        Returns:
            Dictionary with suggested corrections
        """
        pass