from flask import Flask, request, jsonify
import json
import os
import logging
from datetime import datetime, timezone

app = Flask(__name__)

RULES_FILE = "../rules/remote_mock_rules.json"
LOG_FILE = "../logs.json"

# In-memory logs
DATABASE = {"logs": []}

# Load existing logs on startup
if os.path.exists(LOG_FILE):
    try:
        with open(LOG_FILE, "r") as f:
            DATABASE["logs"] = json.load(f)
    except Exception as e:
        print(f"Failed to load existing logs: {e}")

def write_log(level, message, data=None):
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "level": level,
        "message": message
    }
    if data:
        entry["data"] = data
    DATABASE["logs"].append(entry)
    try:
        with open(LOG_FILE, "w") as f:
            json.dump(DATABASE["logs"], f, indent=2)
    except Exception as e:
        print(f"Failed to write log: {e}")

def load_rules():
    if os.path.exists(RULES_FILE):
        try:
            with open(RULES_FILE, "r") as f:
                rules = json.load(f)
                write_log("INFO", "Rules loaded successfully from remote file")
                return rules
        except Exception as e:
            write_log("ERROR", "Failed to read rules from file", {"error": str(e)})
    else:
        write_log("INFO", "Rules file not found, returning empty rule set")
    return {"rules": []}

@app.route("/rules", methods=["GET"])
def get_rules():
    rules = load_rules()
    return jsonify(rules)

if __name__ == "__main__":
    app.run(port=9000, debug=True)
