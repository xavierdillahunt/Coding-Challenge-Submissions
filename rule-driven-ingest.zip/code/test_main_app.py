import io
import unittest
from unittest.mock import patch
import logging
from main import app

class IngestTestCase(unittest.TestCase):
    def setUp(self):
        app.config["TESTING"] = True
        self.client = app.test_client()
        # Suppress logging below ERROR to keep test output clean
        logging.getLogger().setLevel(logging.ERROR)

    def test_upload_valid_csv(self):
        """Test upload with a valid CSV file"""
        data = (
            "claim_id,patient_id,diagnosis_code,claim_amount,service_date,provider_id,status\n"
            "C001,P101,J20.9,150.75,2023-01-15,PRV001,Pending\n"
        )
        rv = self.client.post("/upload", data={"file": (io.BytesIO(data.encode()), "test.csv")})
        self.assertEqual(rv.status_code, 200)
        json_data = rv.get_json()
        self.assertIn("orders", json_data)
        self.assertEqual(len(json_data["orders"]), 1)

    def test_upload_invalid_schema(self):
        """Test upload with invalid CSV schema"""
        data = (
            "bad_col1,bad_col2\n"
            "foo,bar\n"
        )
        rv = self.client.post("/upload", data={"file": (io.BytesIO(data.encode()), "bad.csv")})
        self.assertEqual(rv.status_code, 400)
        json_data = rv.get_json()
        self.assertIn("error", json_data)

    def test_invalid_claim_amount(self):
        """Test upload where claim_amount is invalid"""
        data = (
            "claim_id,patient_id,diagnosis_code,claim_amount,service_date,provider_id,status\n"
            "C001,P101,J20.9,not_a_number,2023-01-15,PRV001,Pending\n"
        )
        rv = self.client.post("/upload", data={"file": (io.BytesIO(data.encode()), "invalid.csv")})
        json_data = rv.get_json()
        self.assertEqual(json_data["invalidCount"], 1)
        self.assertIn("claim_id", json_data["invalidDetails"][0])

    @patch("main.get_rules_from_remote")
    @patch("main.get_rules_from_local")
    def test_rule_application(self, mock_local, mock_remote):
        """Test that rules are applied correctly"""
        mock_remote.return_value = {
            "rules": [
                {
                    "name": "TestRule",
                    "condition": "claim_amount > 100",
                    "action": {"field": "status", "value": "Flagged"},
                }
            ]
        }
        mock_local.return_value = {"rules": []}

        data = (
            "claim_id,patient_id,diagnosis_code,claim_amount,service_date,provider_id,status\n"
            "C001,P101,J20.9,150.75,2023-01-15,PRV001,Pending\n"
            "C002,P102,I10,50,2023-01-16,PRV002,Pending\n"
        )
        rv = self.client.post("/upload", data={"file": (io.BytesIO(data.encode()), "test.csv")})
        json_data = rv.get_json()
        self.assertEqual(json_data["orders"][0]["status"], "Flagged")
        self.assertEqual(json_data["orders"][1]["status"], "Pending")

if __name__ == "__main__":
    unittest.main(verbosity=2)
