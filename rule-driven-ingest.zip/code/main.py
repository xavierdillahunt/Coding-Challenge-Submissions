import os
import json
import csv
import requests
from flask import Flask, request, jsonify
from io import StringIO
from datetime import datetime, timezone
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Absolute paths
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
LOG_FILE = os.path.join(BASE_DIR, "..", "logs.json")
LOCAL_RULES_FILE = os.path.join(BASE_DIR, "..", "rules", "local_rules.json")
REMOTE_RULES_URL = "http://localhost:9000/rules"

# In-memory cache
DATABASE = {"logs": []}

def load_logs_from_file():
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE, "r") as f:
                DATABASE["logs"] = json.load(f)
        except Exception as e:
            logger.error(f"Failed to load logs: {e}")

def save_logs_to_file():
    try:
        with open(LOG_FILE, "w") as f:
            json.dump(DATABASE["logs"], f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save logs: {e}")

def write_log_entry(level, message, data=None):
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "level": level,
        "message": message
    }
    if data:
        entry["data"] = data
    DATABASE["logs"].append(entry)
    save_logs_to_file()

    if level == "ERROR":
        logger.error(message)
    elif level == "WARNING":
        logger.warning(message)
    else:
        logger.info(message)

def get_rules_from_local():
    try:
        with open(LOCAL_RULES_FILE, "r") as f:
            rules = json.load(f)
            write_log_entry("INFO", "Loaded rules from local file")
            return rules
    except Exception as e:
        write_log_entry("ERROR", "Failed to load local rules", {"error": str(e)})
        return {"rules": []}

def get_rules_from_remote():
    try:
        resp = requests.get(REMOTE_RULES_URL, timeout=5)
        resp.raise_for_status()
        write_log_entry("INFO", "Fetched rules from remote")
        return resp.json()
    except Exception as e:
        write_log_entry("ERROR", "Failed to fetch remote rules", {"error": str(e)})
        return None

def _is_number(value):
    try:
        float(value)
        return True
    except Exception:
        return False

def _is_valid_date(date_str):
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except Exception:
        return False

def _safe_eval_condition(condition, record):
    try:
        env = {k: float(v) if _is_number(v) else v for k, v in record.items()}
        return eval(condition, {"__builtins__": {}}, env)
    except Exception as e:
        write_log_entry("ERROR", f"Condition eval error: {condition}", {"record": record, "error": str(e)})
        return False

def apply_rules(records, rules):
    invalid_records = []

    for rule in rules.get("rules", []):
        name = rule.get("name", "UnnamedRule")
        condition = rule.get("condition")
        action = rule.get("action")

        if not condition or not action:
            write_log_entry("WARNING", f"Skipping incomplete rule: {rule}")
            continue

        for record in records[:]:
            try:
                if _safe_eval_condition(condition, record):
                    record[action["field"]] = action["value"]
                    write_log_entry("INFO", f"Rule applied: {name}", {"claim_id": record.get("claim_id")})
            except Exception as e:
                error_msg = f"Rule error {name} on {record.get('claim_id')}"
                write_log_entry("ERROR", error_msg, {"error": str(e)})
                invalid_records.append({
                    "claim_id": record.get("claim_id", "Unknown"),
                    "error": str(e)
                })
                records.remove(record)
    return invalid_records

@app.route("/rules", methods=["POST"])
def upload_local_rules():
    if 'file' not in request.files:
        return jsonify({"error": "No file part in request"}), 400
    file = request.files['file']
    try:
        rules_json = json.loads(file.read())
        with open(LOCAL_RULES_FILE, "w") as f:
            json.dump(rules_json, f, indent=2)
        write_log_entry("INFO", "Local rules updated")
        return {"message": "Local rules updated successfully"}
    except Exception as e:
        write_log_entry("ERROR", "Invalid rules file", {"error": str(e)})
        return jsonify({"error": f"Invalid rules file: {e}"}), 400

@app.route("/upload", methods=["POST"])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part in request"}), 400
    file = request.files['file']
    if not file.filename.endswith(".csv"):
        return jsonify({"error": "Only CSV files are supported"}), 400

    try:
        decoded = file.read().decode("utf-8")
        csv_reader = csv.DictReader(StringIO(decoded))

        expected_fields = ["claim_id", "patient_id", "diagnosis_code", "claim_amount", "service_date", "provider_id", "status"]
        received_fields = [h.strip().lower() for h in csv_reader.fieldnames or []]
        expected_lower = [f.lower() for f in expected_fields]

        if sorted(received_fields) != sorted(expected_lower):
            error_msg = f"CSV schema mismatch. Expected: {expected_fields}, Received: {csv_reader.fieldnames}"
            write_log_entry("ERROR", error_msg)
            return jsonify({
                "error": "CSV schema mismatch",
                "expected": expected_fields,
                "received": csv_reader.fieldnames
            }), 400

        valid_records = []
        invalid_records = []

        for row in csv_reader:
            row = {k.strip().lower(): v for k, v in row.items()}
            record = {key: row.get(key.lower(), "") for key in expected_fields}
            claim_id = record.get("claim_id", "").strip()

            try:
                # Validate claim_id
                if not claim_id:
                    raise ValueError("Missing or empty claim_id")

                # Validate claim_amount
                record["claim_amount"] = float(record["claim_amount"])

                # Validate service_date
                if not _is_valid_date(record["service_date"]):
                    raise ValueError("Invalid service_date format. Expected YYYY-MM-DD")

                valid_records.append(record)

            except Exception as e:
                write_log_entry("ERROR", "Invalid record", {"record": record, "error": str(e)})
                invalid_records.append({
                    "claim_id": claim_id or "Unknown",
                    "error": str(e)
                })

        rules = get_rules_from_remote()
        rules_source = "RemoteRulesEngine"
        if not rules:
            rules = get_rules_from_local()
            rules_source = "LocalRulesEngine"

        invalid_rule_errors = apply_rules(valid_records, rules)
        invalid_records.extend(invalid_rule_errors)

        routing = "priority" if any(x.get("route") == "priority" for x in valid_records) else "normal"

        log_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": "INFO",
            "orders": valid_records,
            "rulesApplied": rules_source,
            "invalidRecordInfo": invalid_records
        }
        DATABASE["logs"].append(log_entry)
        save_logs_to_file()

        return jsonify({
            "orders": valid_records,
            "invalidCount": len(invalid_records),
            "invalidDetails": invalid_records,
            "rulesApplied": rules_source,
            "route": routing
        })

    except Exception as e:
        write_log_entry("ERROR", "Failed to process CSV", {"error": str(e)})
        return jsonify({"error": f"Failed to process CSV: {e}"}), 400

@app.route("/logs", methods=["GET"])
def get_logs():
    load_logs_from_file()
    return jsonify(DATABASE["logs"])

if __name__ == "__main__":
    load_logs_from_file()
    app.run(host="0.0.0.0", port=8000, debug=True)
