#App Info
This is a Flask-based application to process sample healthcare claims using rule-based logic. It supports:

- CSV upload for claims
- Rule application (remote/local)
- Error logging and invalid record tracking
- Test suite with unit tests

#Pre-requisites
-pip install flask requests
-pip install pytest

#Usage Instructions

- Start Remote Rules Server: python remote_rules_server.py (Run from code folder)
- Upload Remote Rules via cURL: curl -X POST http://localhost:8000/rules -F "file=@rules/remote_mock_rules.json"
- Rules should be visible here after upload: http://localhost:9000/rules
- Start Main Flask API: python main.py (Run from code folder)
- Upload Rules via cURL: curl -X POST http://localhost:8000/rules -F "file=@rules/local_rules.json"
- Upload Claims CSV via cURL: curl -X POST http://localhost:8000/upload -F "file=@data/sampleClaims.csv"
- View Logs: curl http://localhost:8000/logs
- Running Unit tests: python test_main_app.py (Run from code folder)
